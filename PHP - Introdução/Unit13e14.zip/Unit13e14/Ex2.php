<?php


    function TransformarMaiusculo($vetor){
        $aux = array();
        $index = 0;
        foreach ($vetor as $item) {
            $aux[$index++] = strtoupper($item);
        }

        return $aux;
    }

    function PrintArray($vetor){
        $alfabeto = array('a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y','z');
        $index = 0;
        foreach ($vetor as $item) {
            echo '[' .strtoupper($alfabeto[$index++] .'] => ' .$item .' ');
        }
    }


    $cor = array ('A' => 'Azul', 'B' => 'Verde', 'c' => 'Vermelho');
    $newArray = TransformarMaiusculo($cor);

    PrintArray($newArray);

?>
