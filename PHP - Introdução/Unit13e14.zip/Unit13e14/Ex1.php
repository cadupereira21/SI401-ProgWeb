<?php
    echo "
<html>
    <body>

        <table style='border-collapse: collapse'>";

    $i = 0;
    $backgroundColor = 0;
    while($i < 9){
        echo "      <tr>";
        $j = 0;
        for ($j; $j < 9; $j++){
            switch ($backgroundColor){
                case 0:
                    echo "          <td style='height: 30px; width: 30px; background-color: white; border: grey solid thin; padding: 0; margin: 0'></td>";
                    $backgroundColor+=1;
                    break;
                case 1:
                    echo "          <td style='height: 30px; width: 30px; background-color: black; border: grey solid thin; padding: 0; margin: 0'></td>";
                    $backgroundColor-=1;
                    break;
            }
        }
        echo "      </tr>";
        $i+=1;
    }

    echo "        </table>

    </body>
</html>";

?>
