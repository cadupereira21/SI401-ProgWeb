<?php

    function LimitesDoArray($vetor){
        $aux = array('menor'=>strlen($vetor[0]), 'maior'=>strlen($vetor[0]));

        foreach ($vetor as $item){
            if(strlen($item) > $aux['maior']){
                $aux['maior'] = strlen($item);
            }

            if(strlen($item) < $aux['menor']){
                $aux['menor'] = strlen($item);
            }
        }

        return $aux;
    }

    $vetor = array("abcd","abc","hjjj", "g", "wer");

    $limites = LimitesDoArray($vetor);

    echo "O menor comprimento é ${limites['menor']} </br>";

    echo "O maior comprimento é ${limites['maior']}";

?>